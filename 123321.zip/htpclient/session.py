import requests


class Session:
    __instance = None

    def __new__(cls, s=None):
        if Session.__instance is None:
            Session.__instance = object.__new__(cls)
            Session.__instance.s = s
            Session.__instance.s.headers.update({'ngrok-skip-browser-warning':True})
            Session.__instance.s.headers.update({'User-Agent':'kjbvdkdbjfhdbhsdkbdslfblfdbcjdsbjhsdfjbsdkcvsld'})
            Session.__instance.s.cookies.set('abuse_interstitial', 'socially-trusted-turtle.ngrok-free.app')
            print(Session.__instance.s.headers)
        return Session.__instance
